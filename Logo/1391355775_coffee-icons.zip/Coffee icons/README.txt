Coffee icons
============

Designer: Dutch Icon (https://www.iconfinder.com/dutchicon)
